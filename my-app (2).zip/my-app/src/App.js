import React from 'react';
import Recipe from './components/Recipe';
import CartContext from './contexts/CartContext';

function App() {
 return (
    <div className="App">
      <CartContext.Provider>
        <Recipe />
      </CartContext.Provider>
    </div>
 );
}

export default App;