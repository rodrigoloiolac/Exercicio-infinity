import React from 'react';

import imagemReceita from './img/imagem.jpg';

const Recipe = () => {
 return (
    <div className="recipe">
      <h1 className="recipe-title">Bruaca</h1>
      <img className="recipe-image" src= {imagemReceita} alt="Receita" />
      <h2 className="recipe-subtitle">Ingredientes</h2>
      <ul className="recipe-ingredients">
        <li>ovo</li>
        <li>manteiga</li>
        <li>farinha de trigo</li>
        <li>açucar</li>
        <li>leite</li>
      </ul>
      <h2 className="recipe-subtitle">Modo de preparo</h2>
      <ol className="recipe-instructions">
        <li>mistute todos os ingredientes ate ficar bem consistente</li>
        <li>Depois faça na frigideira com oleo</li>
        <li>Sirva com açucar por cima</li>
      </ol>
    </div>
 );
};

export default Recipe;